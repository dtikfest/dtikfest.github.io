@extends('layout.app',['title'=>'Produk DTIK Fest 2021'])

@section('content')

<div class="container vh-100 d-flex card flex-row mt-3 mb-3 p-2 justify-content-center">
    <div class="flex-grow-1"></div>
    <div>
        <a href="admin/create" class=" btn btn-primary">Buat baru</a>
    </div>
</div>
@endsection
