

<?php $__env->startSection('content'); ?>



<section class="kategori-pemenang">
    <div class="top-tittle" data-aos="fade-up" data-aos-easing="ease-in-out">
        <h2>Kategori Pemenang</h2>
    </div>
    <div class="container">
        <div class="row">
            <?php $__currentLoopData = $kategoriPemenangMhs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-6 item" data-aos="fade-up" data-aos-delay="50">
                <a href=<?php echo e(asset('/pemenang/personal/'.strtolower($value->id_kategori_pemenang))); ?>>
                    <div class="item-group">
                        <h3><?php echo e($value->kategoriPemenang->nama_kategori_pemenang); ?></h3>
                        <h4>Kategori Individu</h4>
                    </div>
                </a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php $__currentLoopData = $kategoriPemenangTim; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-6 item" data-aos="fade-up" data-aos-delay="50">
                <a href=<?php echo e(asset('/pemenang/tim/'.strtolower($value->id_kategori_pemenang))); ?>>
                    <div class="item-group">
                        <h3><?php echo e($value->kategoriPemenang->nama_kategori_pemenang); ?></h3>
                        <h4>Kategori Tim</h4>
                    </div>
                </a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        
    </div>
</section>
<!-- End Kategori Pemenang -->

<script>
    var content = document.getElementsByClassName("hidden-content");
    var showbtn = document.getElementsByClassName("show");
    var hidebtn = document.getElementsByClassName("hide");

    function showContent() {
        content[0].style.display = "block";
        showbtn[0].style.display = "none";
        hidebtn[0].style.display = "block";

        console.log("success");
    }

    function hideContent() {
        content[0].style.display = "none";
        showbtn[0].style.display = "block";
        hidebtn[0].style.display = "none";
    }

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($tahun.'.layout.app',['title'=>'Pemenang DTIK Fest 2021'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\doc\lOCALHOST\PROJECT\KULIAH\sem4-RPL-DTIKFES\resources\views/2021/pemenang/index.blade.php ENDPATH**/ ?>