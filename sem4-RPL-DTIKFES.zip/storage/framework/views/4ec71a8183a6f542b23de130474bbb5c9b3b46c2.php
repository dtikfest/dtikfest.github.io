

<?php $__env->startSection('content'); ?>

<!-- ======= Mobile Section ======= -->
<section id="product">
    <div class="top-tittle" data-aos="fade-right" data-aos-easing="ease-in-out">
        <h2><?php echo e($kategori_produk->nama_kategori); ?></h2>
    </div>
    <div class="container">
        <div class="row">
            
            
            <?php $__empty_1 = true; $__currentLoopData = $kategori_produk->produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $katPro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-lg-4 col-md-6 app" data-aos="zoom-in">
                <a href="<?php echo e(asset('/detailProdukTim/'.$katPro->tim->id_tim)); ?>">
                    <div class="product-box">
                        
                        <img src="<?php echo e(asset('aset-'.$tahun.'/img/produk/'. $katPro->id_produk. preg_replace("/[^A-Za-z0-9]/", "", $katPro->nama_produk).'/produk.png')); ?>"
                            alt="">
                        <div class="desc">
                            <h3><?php echo e($katPro->nama_produk); ?></h3>
                            <h4><?php echo e($katPro->tim->nama_tim); ?></h4>
                        </div>
                    </div>
                </a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class=" vh-100">
                <div class=" alert alert-info mt-5 text-center">
                    Belum ada Post.
                </div>
            </div>
            <?php endif; ?>
        </div>

        
    </div>
</section>
<!-- End Mobile -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make($tahun.'.layout.app',['title'=>'Produk DTIK Fest 2021'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\doc\lOCALHOST\PROJECT\KULIAH\sem4-RPL-DTIKFES\resources\views/2021/produk/index.blade.php ENDPATH**/ ?>