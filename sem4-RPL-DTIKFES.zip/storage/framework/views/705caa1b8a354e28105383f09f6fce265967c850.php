<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">

    <title><?php echo e($title ?? 'DTIK Fest'); ?></title>
    <meta content="" name="description">
    <meta content="" name="keywords">

    <link rel="icon" type="image/png" href="<?php echo e(asset('aset-'.$tahun.'/img/DTIK Fest.png')); ?>">

    <!-- Google Fonts -->
    <link
        href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i"
        rel="stylesheet">

    <!-- Vendor CSS Files -->
    <link href="<?php echo e(asset('aset-'.$tahun.'/vendor/aos/aos.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('aset-'.$tahun.'/vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('aset-'.$tahun.'/vendor/bootstrap-icons/bootstrap-icons.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('aset-'.$tahun.'/vendor/boxicons/css/boxicons.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('aset-'.$tahun.'/vendor/swiper/swiper-bundle.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('aset-'.$tahun.'/vendor/glightbox/css/glightbox.min.css')); ?>" rel="stylesheet">

    <!-- Template Main CSS File -->
    <link href="<?php echo e(asset('aset-'.$tahun.'/css/style.css')); ?>" rel="stylesheet">
    
</head>

<body>

    <?php if(request()->is('admin/*')): ?>
    <?php echo $__env->yieldContent('content'); ?>
    <?php else: ?>
    <?php echo $__env->make($tahun.'/layout/frontend-navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('content'); ?>
    <?php echo $__env->make($tahun.'/layout/frontend-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

    <div class="preloader">
        <div class="ring">
            <div class="ring-img">
                <img src="<?php echo e(asset('/img/DTIK Fest.png')); ?>" class="img-fluid" alt="">
            </div>
            <span></span>
        </div>
    </div>

    <script src="//code.tidio.co/0emm6blrukygdj0stmu77wtqbnt7u6dh.js" async></script>
</body>

<!-- Vendor JS Files -->
<script src="<?php echo e(asset('aset-'.$tahun.'/vendor/aos/aos.js')); ?>"></script>
<script src="<?php echo e(asset('aset-'.$tahun.'/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('aset-'.$tahun.'/vendor/swiper/swiper-bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('aset-'.$tahun.'/vendor/glightbox/js/glightbox.min.js')); ?>"></script>

<!-- Template Main JS File -->
<script src="<?php echo e(asset('aset-'.$tahun.'/js/main.js')); ?>"></script>
<script>
    var preloader = document.querySelector(".preloader");
    window.addEventListener("load", vanish);

    function vanish() {
        preloader.classList.add("dissapear");
    }

</script>

</html>
<?php /**PATH D:\doc\lOCALHOST\PROJECT\KULIAH\dtikfest.github.io\resources\views/2021/layout/app.blade.php ENDPATH**/ ?>