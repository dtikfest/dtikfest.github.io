

<?php $__env->startSection('content'); ?>



<!-- Peringkat Pemenang -->
<section id="peringkat">
    <div class="top-tittle" data-aos="fade-right" data-aos-easing="ease-in-out">
        <h2><?php echo e($peringkatJuara[0]->kategoriPemenang->nama_kategori_pemenang); ?></h2>
    </div>
    <div class="container">
        <div class="row justify-content-center">
            
            <?php if($jenis=='solo'): ?>
            <?php $__currentLoopData = $peringkatJuara; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4 col-md-6 app" data-aos="zoom-in">
                <a href="#">
                    <div class="peringkat-box">
                        
                        <img src="<?php echo e(asset('aset-'.$tahun.'/img/mahasiswa/'.$value->mhs->foto)); ?>" alt=""
                            style="height:300px">
                        <div class="desc">
                            <h3><?php echo e($value->mhs->nama_mahasiswa); ?></h3>
                            
                        </div>
                    </div>
                </a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>

            <?php if($jenis=='tim'): ?>
            <?php $__currentLoopData = $peringkatJuara; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4 col-md-6 app" data-aos="zoom-in">
                <a href=<?php echo e(asset('/detailProdukTim/'.$value->tim->id_tim)); ?>>
                    <div class="peringkat-box">
                        <img src=<?php echo e(asset('aset-'.$tahun.'/img/produk/'.$value->id_tim. preg_replace("/[^A-Za-z0-9]/", "", $value->tim->produk->nama_produk).'/produk.png')); ?>

                            alt="">
                        <div class="desc">
                            <h3><?php echo e($value->tim->produk->nama_produk); ?></h3>
                            <h4>Tim <?php echo e($value->tim->nama_tim); ?></h4>
                        </div>
                    </div>
                </a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>

            
        </div>
    </div>
</section>
<!-- End Peringkat Pemenang -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make($tahun.'.layout.app',['title'=>'Peringkat Pemenang DTIK Fest 2021'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\doc\lOCALHOST\PROJECT\KULIAH\sem4-RPL-DTIKFES\resources\views/2021/pemenang/peringkatJuara.blade.php ENDPATH**/ ?>